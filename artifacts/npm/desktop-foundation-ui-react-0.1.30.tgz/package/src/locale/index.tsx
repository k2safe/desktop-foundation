import { createContext, useContext, useMemo, useRef, type ReactNode } from "react";

export type LocaleCode = "zh-CN" | "en-US" | (string & {});
export type LocaleMessageValue = string | number;
export type LocaleMessageValues = Record<string, LocaleMessageValue>;
export type LocaleDictionary = Record<string, string>;
export type LocaleDateValue = Date | number | string;

export interface LocaleMissingKeyEvent {
  key: string;
  locale: LocaleCode;
  fallback?: string;
  resolvedFromFallback?: boolean;
  valueKeys?: string[];
  timestamp: number;
}

export interface LocaleMissingKeyObserver {
  onMissingKey?: (event: LocaleMissingKeyEvent) => void;
}

export interface LocaleFormatDefaults {
  locale?: LocaleCode;
  currency?: string;
  timeZone?: string;
}

export interface LocaleFormatters {
  number: (value: number, options?: Intl.NumberFormatOptions) => string;
  currency: (value: number, currencyOrOptions?: string | Intl.NumberFormatOptions, options?: Intl.NumberFormatOptions) => string;
  date: (value: LocaleDateValue, options?: Intl.DateTimeFormatOptions) => string;
  time: (value: LocaleDateValue, options?: Intl.DateTimeFormatOptions) => string;
  dateTime: (value: LocaleDateValue, options?: Intl.DateTimeFormatOptions) => string;
}

export interface LocaleContextValue {
  locale: LocaleCode;
  messages: LocaleDictionary;
  t: (key: string, values?: LocaleMessageValues, fallback?: string) => string;
  format: LocaleFormatters;
}

export interface LocaleProviderProps {
  locale?: LocaleCode;
  messages?: LocaleDictionary;
  dictionaries?: Record<string, LocaleDictionary>;
  formatDefaults?: LocaleFormatDefaults;
  onMissingKey?: (event: LocaleMissingKeyEvent) => void;
  missingKeyObserver?: LocaleMissingKeyObserver;
  warnOnMissingKey?: boolean;
  children: ReactNode;
}

export const zhCNMessages: LocaleDictionary = {
  "access.deniedDescription": "当前账号没有访问此功能的权限。",
  "access.deniedTitle": "无权访问",
  "common.apply": "应用",
  "common.cancel": "取消",
  "common.clear": "清空",
  "common.close": "关闭",
  "common.confirm": "确认",
  "common.copy": "复制",
  "common.copied": "已复制",
  "common.hide": "隐藏",
  "common.loading": "加载中",
  "common.next": "下一页",
  "common.previous": "上一页",
  "common.show": "显示",
  "combobox.empty": "暂无选项",
  "combobox.search": "搜索",
  "command.close": "关闭命令面板",
  "command.empty": "暂无命令",
  "command.group": "命令",
  "command.search": "搜索命令",
  "command.title": "命令",
  "dataTable.selected": "已选择 {count} 项",
  "dateRange.end": "结束日期",
  "dateRange.start": "开始日期",
  "debug.audit": "审计",
  "debug.clearAudit": "清空审计",
  "debug.clearRequests": "清空请求",
  "debug.noAuditEvents": "暂无审计事件。",
  "debug.noRequests": "暂无请求记录。",
  "debug.requests": "请求",
  "debug.runtime": "运行时",
  "debug.session": "会话",
  "debug.title": "调试面板",
  "debug.unknown": "未知",
  "layout.editProfile": "编辑个人信息",
  "layout.logout": "退出登录",
  "layout.mainMenu": "主菜单",
  "layout.topMenu": "顶部菜单",
  "layout.user": "用户",
  "login.account": "账号",
  "login.accountPlaceholder": "账号或邮箱",
  "login.brandPanelSubtitle": "使用产品账号继续。",
  "login.brandPanelTitle": "登录",
  "login.brandPanelVisualDescription": "品牌、登录文案、业务字段和认证逻辑都留在产品适配层。",
  "login.brandPanelVisualTitle": "一个底座，业务归产品。",
  "login.centerCardSubtitle": "登录后继续。",
  "login.centerCardTitle": "欢迎回来",
  "login.continue": "继续",
  "login.password": "密码",
  "login.passwordPlaceholder": "密码",
  "login.remember": "记住我",
  "login.secureDesktop": "安全桌面",
  "login.signIn": "登录",
  "login.splitSubtitle": "进入桌面工作区。",
  "login.splitTitle": "登录",
  "login.splitVisualDescription": "可复用的桌面壳，用于安全的产品流程、本地能力和版本更新。",
  "login.splitVisualTitle": "面向桌面的业务操作。",
  "login.workbenchSubtitle": "打开桌面命令工作区。",
  "login.workbenchTitle": "操作员登录",
  "login.workbenchVisualDescription": "高密度布局、本地 bridge 能力、更新检查和产品自有认证。",
  "login.workbenchVisualTitle": "为高频运营工作而建。",
  "modal.close": "关闭",
  "offline.message": "当前网络不可用",
  "pagination.next": "下一页",
  "pagination.previous": "上一页",
  "search.label": "搜索",
  "search.placeholder": "搜索",
  "settings.sections": "设置分组",
  "status.active": "启用",
  "status.danger": "失败",
  "status.disabled": "停用",
  "status.enabled": "启用",
  "status.error": "异常",
  "status.failed": "失败",
  "status.inactive": "停用",
  "status.normal": "正常",
  "status.online": "在线",
  "status.pending": "处理中",
  "status.processing": "处理中",
  "status.queued": "队列中",
  "status.reviewing": "需复核",
  "status.running": "运行中",
  "status.success": "成功",
  "status.succeeded": "成功",
  "status.warning": "需复核",
  "table.emptyTitle": "暂无数据",
  "table.selectAll": "选择全部",
  "table.selectRow": "选择行 {key}",
  "toast.close": "关闭通知",
  "toast.region": "通知",
  "columns.settings": "列设置",
  "columns.reset": "全部显示",
  "columns.moveUp": "上移",
  "columns.moveDown": "下移",
  "error.title": "出现错误",
  "errorBoundary.description": "请重试，或联系支持人员。",
  "errorBoundary.reset": "重试",
  "errorBoundary.title": "页面出现错误",
  "filePicker.choose": "选择文件",
  "filePicker.empty": "未选择文件"
};

export const enUSMessages: LocaleDictionary = {
  "access.deniedDescription": "Your account does not have access to this feature.",
  "access.deniedTitle": "Access denied",
  "common.apply": "Apply",
  "common.cancel": "Cancel",
  "common.clear": "Clear",
  "common.close": "Close",
  "common.confirm": "Confirm",
  "common.copy": "Copy",
  "common.copied": "Copied",
  "common.hide": "Hide",
  "common.loading": "Loading",
  "common.next": "Next",
  "common.previous": "Previous",
  "common.show": "Show",
  "combobox.empty": "No options",
  "combobox.search": "Search",
  "command.close": "Close command palette",
  "command.empty": "No commands",
  "command.group": "Commands",
  "command.search": "Search commands",
  "command.title": "Command",
  "dataTable.selected": "{count} selected",
  "dateRange.end": "End date",
  "dateRange.start": "Start date",
  "debug.audit": "Audit",
  "debug.clearAudit": "Clear audit",
  "debug.clearRequests": "Clear requests",
  "debug.noAuditEvents": "No audit events recorded.",
  "debug.noRequests": "No requests recorded.",
  "debug.requests": "Requests",
  "debug.runtime": "Runtime",
  "debug.session": "Session",
  "debug.title": "Debug Panel",
  "debug.unknown": "unknown",
  "layout.editProfile": "Edit profile",
  "layout.logout": "Log out",
  "layout.mainMenu": "Main menu",
  "layout.topMenu": "Top menu",
  "layout.user": "User",
  "login.account": "Account",
  "login.accountPlaceholder": "Account or email",
  "login.brandPanelSubtitle": "Use your product account to continue.",
  "login.brandPanelTitle": "Sign in",
  "login.brandPanelVisualDescription": "Keep brand, login copy, business fields, and authentication inside the product adapter.",
  "login.brandPanelVisualTitle": "One foundation, product-owned business.",
  "login.centerCardSubtitle": "Sign in to continue.",
  "login.centerCardTitle": "Welcome back",
  "login.continue": "Continue",
  "login.password": "Password",
  "login.passwordPlaceholder": "Password",
  "login.remember": "Remember me",
  "login.secureDesktop": "Secure desktop",
  "login.signIn": "Sign in",
  "login.splitSubtitle": "Access the desktop workspace.",
  "login.splitTitle": "Sign in",
  "login.splitVisualDescription": "A reusable shell for secure product workflows, local capabilities, and release updates.",
  "login.splitVisualTitle": "Desktop-ready operations.",
  "login.workbenchSubtitle": "Open the desktop command workspace.",
  "login.workbenchTitle": "Operator sign in",
  "login.workbenchVisualDescription": "Dense layouts, local bridge capabilities, update checks, and product-owned authentication.",
  "login.workbenchVisualTitle": "Built for repeated operational work.",
  "modal.close": "Close",
  "offline.message": "Network unavailable",
  "pagination.next": "Next",
  "pagination.previous": "Previous",
  "search.label": "Search",
  "search.placeholder": "Search",
  "settings.sections": "Settings sections",
  "status.active": "Active",
  "status.danger": "Failed",
  "status.disabled": "Disabled",
  "status.enabled": "Enabled",
  "status.error": "Error",
  "status.failed": "Failed",
  "status.inactive": "Inactive",
  "status.normal": "Normal",
  "status.online": "Online",
  "status.pending": "Pending",
  "status.processing": "Processing",
  "status.queued": "Queued",
  "status.reviewing": "Needs review",
  "status.running": "Running",
  "status.success": "Success",
  "status.succeeded": "Succeeded",
  "status.warning": "Needs review",
  "table.emptyTitle": "No data",
  "table.selectAll": "Select all",
  "table.selectRow": "Select row {key}",
  "toast.close": "Close notification",
  "toast.region": "Notifications",
  "columns.settings": "Column settings",
  "columns.reset": "Show all",
  "columns.moveUp": "Move up",
  "columns.moveDown": "Move down",
  "error.title": "Something went wrong",
  "errorBoundary.description": "Try again, or contact support.",
  "errorBoundary.reset": "Try again",
  "errorBoundary.title": "Page error",
  "filePicker.choose": "Choose file",
  "filePicker.empty": "No file selected"
};

export const builtinLocaleDictionaries: Record<string, LocaleDictionary> = {
  "zh-CN": zhCNMessages,
  "en-US": enUSMessages
};

function formatMessage(template: string, values?: LocaleMessageValues) {
  if (!values) return template;
  return template.replace(/\{([A-Za-z0-9_.-]+)\}/g, (match, key) => {
    const value = values[key];
    return value === undefined ? match : String(value);
  });
}

function toDate(value: LocaleDateValue) {
  return value instanceof Date ? value : new Date(value);
}

const dateTimeOptionKeys = new Set([
  "dateStyle",
  "timeStyle",
  "weekday",
  "era",
  "year",
  "month",
  "day",
  "dayPeriod",
  "hour",
  "minute",
  "second",
  "fractionalSecondDigits",
  "timeZoneName"
]);

function hasDateTimeStyleOptions(options?: Intl.DateTimeFormatOptions) {
  return options ? Object.keys(options).some((key) => dateTimeOptionKeys.has(key)) : false;
}

export function createLocaleFormatters(locale: LocaleCode, defaults: LocaleFormatDefaults = {}): LocaleFormatters {
  const resolvedLocale = defaults.locale ?? locale;

  return {
    number: (value, options) => new Intl.NumberFormat(resolvedLocale, options).format(value),
    currency: (value, currencyOrOptions, options) => {
      const currency = typeof currencyOrOptions === "string" ? currencyOrOptions : defaults.currency ?? "USD";
      const mergedOptions = typeof currencyOrOptions === "object" ? currencyOrOptions : options;
      return new Intl.NumberFormat(resolvedLocale, { style: "currency", currency, ...mergedOptions }).format(value);
    },
    date: (value, options) =>
      new Intl.DateTimeFormat(resolvedLocale, { timeZone: defaults.timeZone, ...(hasDateTimeStyleOptions(options) ? {} : { dateStyle: "medium" }), ...options }).format(toDate(value)),
    time: (value, options) =>
      new Intl.DateTimeFormat(resolvedLocale, { timeZone: defaults.timeZone, ...(hasDateTimeStyleOptions(options) ? {} : { timeStyle: "short" }), ...options }).format(toDate(value)),
    dateTime: (value, options) =>
      new Intl.DateTimeFormat(resolvedLocale, {
        timeZone: defaults.timeZone,
        ...(hasDateTimeStyleOptions(options) ? {} : { dateStyle: "medium", timeStyle: "short" }),
        ...options
      }).format(toDate(value))
  };
}

export function getMissingLocaleKeys(reference: LocaleDictionary, target: LocaleDictionary) {
  return Object.keys(reference).filter((key) => target[key] === undefined);
}

function createLocaleContextValue(locale: LocaleCode, messages: LocaleDictionary, format: LocaleFormatters): LocaleContextValue {
  return {
    locale,
    messages,
    t: (key, values, fallback) => formatMessage(messages[key] ?? fallback ?? key, values),
    format
  };
}

const defaultLocaleContext = createLocaleContextValue("zh-CN", zhCNMessages, createLocaleFormatters("zh-CN"));
const LocaleContext = createContext<LocaleContextValue>(defaultLocaleContext);

export function LocaleProvider({
  locale = "zh-CN",
  messages,
  dictionaries,
  formatDefaults,
  onMissingKey,
  missingKeyObserver,
  warnOnMissingKey = false,
  children
}: LocaleProviderProps) {
  const reportedMissingKeysRef = useRef(new Set<string>());
  const value = useMemo(() => {
    const localeMessages = {
      ...(builtinLocaleDictionaries[locale] ?? {}),
      ...(dictionaries?.[locale] ?? {}),
      ...(messages ?? {})
    };
    const mergedMessages = {
      ...zhCNMessages,
      ...localeMessages
    };
    const format = createLocaleFormatters(locale, formatDefaults);
    return {
      ...createLocaleContextValue(locale, mergedMessages, format),
      t: (key: string, values?: LocaleMessageValues, fallback?: string) => {
        const hasKey = Object.prototype.hasOwnProperty.call(mergedMessages, key);
        const hasLocaleKey = Object.prototype.hasOwnProperty.call(localeMessages, key);
        if (!hasLocaleKey || !hasKey) {
          const missingKeyId = `${locale}:${key}`;
          if (!reportedMissingKeysRef.current.has(missingKeyId)) {
            reportedMissingKeysRef.current.add(missingKeyId);
            const event: LocaleMissingKeyEvent = {
              key,
              locale,
              fallback,
              resolvedFromFallback: hasKey,
              valueKeys: values ? Object.keys(values) : undefined,
              timestamp: Date.now()
            };
            missingKeyObserver?.onMissingKey?.(event);
            onMissingKey?.(event);
            if (warnOnMissingKey && typeof console !== "undefined") {
              console.warn(`[desktop-foundation:i18n] Missing locale key "${key}" for ${locale}`);
            }
          }
        }
        return formatMessage(hasKey ? mergedMessages[key] : fallback ?? key, values);
      }
    };
  }, [dictionaries, formatDefaults, locale, messages, missingKeyObserver, onMissingKey, warnOnMissingKey]);

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  return useContext(LocaleContext);
}
